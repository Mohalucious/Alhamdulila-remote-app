# main.py - Kivy UI wrapper for Alhamdulila bot
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.clock import Clock
import threading, os, time

# Import the bot module (alhamdulila.py should be in same dir)
import alhamdulila

class RootWidget(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', padding=10, spacing=10, **kwargs)
        self.token_input = TextInput(text=os.environ.get('DERIV_TOKEN',''), hint_text='Deriv Token', size_hint_y=None, height=40)
        self.appid_input = TextInput(text=os.environ.get('DERIV_APP_ID','1089'), hint_text='Deriv App ID', size_hint_y=None, height=40)
        self.status = Label(text='Status: idle', size_hint_y=None, height=40)
        self.start_btn = Button(text='Start Bot (exec allowed)', size_hint_y=None, height=50, background_color=(0,1,0,1))
        self.stop_btn = Button(text='Stop Bot (pause exec)', size_hint_y=None, height=50, background_color=(1,0,0,1))
        self.start_btn.bind(on_press=self.on_start)
        self.stop_btn.bind(on_press=self.on_stop)
        self.add_widget(Label(text='Alhamdulila — Forex AI Mobile Bot', size_hint_y=None, height=40))
        self.add_widget(self.appid_input)
        self.add_widget(self.token_input)
        self.add_widget(self.status)
        self.add_widget(self.start_btn)
        self.add_widget(self.stop_btn)
        self.bot_thread = None
        self.engine = None
        self.broker = None

    def on_start(self, *args):
        # Save token into environment (used by bot module)
        os.environ['DERIV_APP_ID'] = self.appid_input.text.strip()
        os.environ['DERIV_TOKEN'] = self.token_input.text.strip()
        if self.bot_thread and self.bot_thread.is_alive():
            # allow trade execution only
            alhamdal_state = getattr(alhamdal_state := None, 'dummy', None)
            # toggle exec_allowed if engine exists
            try:
                alhamdal_state = getattr(alhamdal_state, 'dummy', None)
            except:
                pass
        # If engine not started, start background engine and UI
        if not self.bot_thread or not self.bot_thread.is_alive():
            self.status.text = 'Status: starting...'
            self.bot_thread = threading.Thread(target=self._start_engine, daemon=True)
            self.bot_thread.start()
            # wait a moment
            Clock.schedule_once(lambda dt: setattr(self.status, 'text', 'Status: running (exec allowed)'), 1)
        else:
            # allow execution on running engine
            if alhamdal_app_engine := getattr(alhamdal_app_engine_ref, 'engine', None):
                alhamdal_app_engine['exec_allowed'] = True
            self.status.text = 'Status: running (exec allowed)'

    def on_stop(self, *args):
        # pause trade execution only
        try:
            if alhamdal_app_engine := getattr(alhamdal_app_engine_ref, 'engine', None):
                alhamdal_app_engine['exec_allowed'] = False
            self.status.text = 'Status: running (exec paused)'
        except Exception as e:
            self.status.text = 'Status: error stopping exec: ' + str(e)

    def _start_engine(self):
        try:
            # Start engine and UI from alhamdulila as embedded mode
            # The alhamdulila.py script exposes start_engine_and_ui function; call it.
            engine, broker = alhamdulila.start_engine_and_ui(broker_name='deriv', mode='paper')
            # save engine state to a global ref for control
            global alhamdal_app_engine_ref
            class R: pass
            alhamdal_app_engine_ref = R()
            alhamdal_app_engine_ref.engine = alhamnul = {'exec_allowed': True, 'engine': engine}
            # update status periodically
            while True:
                time.sleep(2)
        except Exception as e:
            self.status.text = 'Engine error: ' + str(e)

class AlhamApp(App):
    def build(self):
        return RootWidget()

if __name__ == '__main__':
    AlhamApp().run()
