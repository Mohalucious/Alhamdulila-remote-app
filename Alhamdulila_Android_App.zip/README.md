Alhamdulila Android App - Build & Install

This project contains a Kivy-based Android frontend and the Alhamdulila bot module.

To build an APK locally (Linux), install Buildozer (recommended in Ubuntu):
  sudo apt update && sudo apt install -y python3-pip build-essential git
  pip install --user buildozer
  sudo apt install -y openjdk-11-jdk zip unzip
  # install Android SDK/NDK per buildozer docs

Then run in project dir:
  buildozer -v android debug

Or use GitHub Actions (provided workflow) to build in cloud and download the APK release.

IMPORTANT: Building an APK that embeds heavy Python libs (pandas, numpy) may be large and complex.
Alternative recommended approach: run the bot on a small VPS/server and use the Android app as a lightweight controller UI.
