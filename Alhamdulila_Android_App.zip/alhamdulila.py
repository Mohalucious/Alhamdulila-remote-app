#!/usr/bin/env python3
"""
Alhamdulila.py — All-in-one Forex AI Mobile Bot (Deriv-ready)

Features:
- Integrated strategy: SMA/RSI/MACD multi-timeframe confirmation + SMC heuristics (FVG, order blocks)
- Meta-learner for weighting signals and a simple psychology manager
- Deriv broker adapter using WebSocket (falls back to simulated mode if websocket not installed)
- Flask-based mobile UI with green (Start) and red (Stop) buttons which control trade execution only
- Backtest mode via CSV/Parquet tick file (basic)
- Mobile-friendly instructions included below (UserLAnd on Android)

IMPORTANT SAFETY NOTE:
- This is a development prototype. Do NOT run with real capital until you have thoroughly backtested and paper-tested.
- Use Deriv demo credentials and sandbox environment where applicable.
- The Deriv contract mapping is simplified: lot -> stake mapping. Adjust before using live accounts.

USAGE (basic):
1. Install UserLAnd from Play Store and create an Ubuntu session (or use any Linux machine).
2. Install dependencies:
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   Where requirements.txt should include: flask pandas numpy websocket-client (optional), scikit-learn (optional)
   Example: pip install flask pandas numpy websocket-client scikit-learn
3. Place Alhamdulila.py on the device, then run:
   export DERIV_APP_ID="1089"      # replace with your app_id
   export DERIV_TOKEN="your_token" # replace with your token
   python3 Alhamdulila.py --mode paper
4. Open your phone browser to http://127.0.0.1:5000 to access the UI (or use the device IP if remote).
   Use the green Start button to allow trade execution, and red Stop to pause execution.
5. For demo only: use --mode deriv_demo to test connection and a simple demo order.

File created by assistant. Keep credentials private.
"""

import os
import argparse
import time
import json
import threading
import traceback
from datetime import datetime
from functools import wraps

import pandas as pd
import numpy as np
from flask import Flask, render_template_string, request, redirect, url_for, jsonify

# optional websocket-client for Deriv -- the program will handle missing lib gracefully
try:
    import websocket
except Exception:
    websocket = None

# ---------------- Configuration ----------------
DERIV_WS_BASE = "wss://ws.derivws.com/websockets/v3?app_id="
LOOP_INTERVAL_SEC = 5  # main loop polling interval (seconds)
RISK_PER_TRADE = 0.01
MIN_EQUITY = 50.0

# ---------------- Utilities ----------------
def now_utc():
    return datetime.utcnow()

# ---------------- Technical indicators ----------------
def sma(series, n):
    return series.rolling(n).mean()

def rsi(series, n=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.ewm(span=n, adjust=False).mean()
    ma_down = down.ewm(span=n, adjust=False).mean()
    rs = ma_up / ma_down
    return 100 - (100 / (1 + rs))

def macd(series, fast=12, slow=26, signal=9):
    ema_fast = series.ewm(span=fast, adjust=False).mean()
    ema_slow = series.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

# ---------------- SMC heuristics ----------------
def detect_fvg_from_ohlc(df):
    fvg = []
    for i in range(1, len(df)-1):
        prev = df.iloc[i-1]; cur = df.iloc[i]; nxt = df.iloc[i+1]
        cur_body_low = min(cur['open'], cur['close']); cur_body_high = max(cur['open'], cur['close'])
        prev_body_low = min(prev['open'], prev['close']); prev_body_high = max(prev['open'], prev['close'])
        next_body_low = min(nxt['open'], nxt['close']); next_body_high = max(nxt['open'], nxt['close'])
        if cur_body_low > prev_body_high and cur_body_low > next_body_high:
            fvg.append({'start': df.index[i-1], 'end': df.index[i+1], 'low': prev_body_high, 'high': cur_body_low})
        if cur_body_high < prev_body_low and cur_body_high < next_body_low:
            fvg.append({'start': df.index[i-1], 'end': df.index[i+1], 'low': cur_body_high, 'high': prev_body_low})
    return fvg

def detect_order_blocks_from_ohlc(df):
    obs = []
    for i in range(1, len(df)-2):
        prev = df.iloc[i-1]; cur = df.iloc[i]; nxt = df.iloc[i+1]
        if prev['close'] < prev['open'] and cur['close'] > cur['open'] and cur['close'] > prev['open']:
            if nxt['close'] > cur['close']:
                obs.append({'time': df.index[i-1], 'side':'bull', 'high':prev['high'], 'low':prev['low']})
        if prev['close'] > prev['open'] and cur['close'] < cur['open'] and cur['close'] < prev['open']:
            if nxt['close'] < cur['close']:
                obs.append({'time': df.index[i-1], 'side':'bear', 'high':prev['high'], 'low':prev['low']})
    return obs

# ---------------- Position sizing & Psychology ----------------
def position_size(account_balance, stop_pips, pip_value=0.0001, risk_fraction=RISK_PER_TRADE):
    risk_amount = account_balance * risk_fraction
    if stop_pips <= 0:
        return 0.01
    lot = risk_amount / (stop_pips * pip_value)
    return max(0.01, round(lot, 2))

class PsychologyManager:
    def __init__(self):
        self.consecutive_losses = 0
        self.daily_loss = 0.0
        self.last_reset = now_utc().date()

    def record_result(self, pnl):
        if pnl < 0:
            self.consecutive_losses += 1
            self.daily_loss += -pnl
        else:
            self.consecutive_losses = 0
        if now_utc().date() != self.last_reset:
            self.daily_loss = 0.0
            self.last_reset = now_utc().date()

    def allow_trade(self):
        if self.consecutive_losses >= 3:
            return False
        if self.daily_loss > 0.04:  # placeholder relative threshold
            return False
        return True

# ---------------- Meta Learner ----------------
class MetaLearner:
    def __init__(self, signal_count=4):
        self.weights = np.ones(signal_count) / signal_count
        self.ema_perf = np.zeros(signal_count)

    def update(self, signal_vector, pnl):
        self.ema_perf = 0.9 * self.ema_perf + 0.1 * np.array(signal_vector) * pnl
        exp = np.exp(self.ema_perf)
        self.weights = exp / exp.sum()

    def predict_weighted_signal(self, signals):
        return float(np.dot(self.weights, signals))

# ---------------- Broker Adapters ----------------
class BrokerAdapter:
    """Simple simulator / placeholder adapter to make calls consistent"""
    def __init__(self):
        self.balance = 10000.0
    def connect(self, **kwargs):
        return
    def get_account(self):
        return {'balance': self.balance}
    def create_order(self, instrument, units, stop=None, tp=None):
        # simulate immediate fill record
        return {'status':'simulated', 'units': units, 'stop': stop, 'tp': tp, 'fill_price': None}

class DerivAdapter:
    """
    Minimal Deriv adapter using WebSocket. This implementation uses websocket-client library.
    It uses simple 'ticks' and 'buy' payloads. Adjust payloads for your Deriv account and instruments.
    """
    def __init__(self, app_id: str, token: str):
        self.app_id = app_id
        self.token = token
        self.ws = None
        self.connected = False
        self.balance = 0.0

    def connect(self):
        if websocket is None:
            print('websocket-client not installed — running in simulated Deriv mode.')
            self.connected = False
            return
        url = DERIV_WS_BASE + str(self.app_id)
        try:
            self.ws = websocket.create_connection(url, timeout=10)
            # authorize
            auth = {"authorize": self.token}
            self.ws.send(json.dumps(auth))
            res = json.loads(self.ws.recv())
            if 'error' in res:
                raise Exception(f"Deriv auth error: {res['error']}")
            self.connected = True
            print('Deriv connected, login:', res.get('authorize', {}).get('loginid'))
        except Exception as e:
            print('Deriv connection failed:', e)
            self.connected = False

    def get_account(self):
        if not self.connected:
            return {'balance': self.balance}
        try:
            req = {"balance": 1}
            self.ws.send(json.dumps(req))
            res = json.loads(self.ws.recv())
            if 'balance' in res:
                self.balance = float(res['balance']['balance'])
            return {'balance': self.balance}
        except Exception as e:
            print('get_account error', e)
            return {'balance': self.balance}

    def get_tick(self, symbol='frxEURUSD'):
        if not self.connected:
            return None
        try:
            req = {"ticks": symbol}
            self.ws.send(json.dumps(req))
            res = json.loads(self.ws.recv())
            if 'tick' in res:
                tick = res['tick']
                return {'time': tick.get('epoch'), 'quote': tick.get('quote')}
            return None
        except Exception as e:
            print('get_tick error', e)
            return None

    def create_order(self, symbol='frxEURUSD', amount=1.0, contract_type='CALL', duration=1, duration_unit='t'):
        if not self.connected:
            # simulate a contract response when offline
            return {'status':'simulated','symbol':symbol,'amount':amount,'contract_type':contract_type}
        try:
            payload = {
                "buy": 1,
                "price": amount,
                "parameters": {
                    "amount": amount,
                    "basis": "stake",
                    "contract_type": contract_type,
                    "currency": "USD",
                    "duration": duration,
                    "duration_unit": duration_unit,
                    "symbol": symbol
                }
            }
            self.ws.send(json.dumps(payload))
            res = json.loads(self.ws.recv())
            return res
        except Exception as e:
            print('create_order error', e)
            return {'error': str(e)}

# ---------------- Strategy Engine ----------------
class StrategyEngine:
    def __init__(self, broker_adapter):
        self.broker = broker_adapter
        self.meta = MetaLearner(signal_count=4)
        self.psych = PsychologyManager()
        self.order_history = []

    def compute_signals(self, df):
        df = df.copy()
        df['sma20'] = sma(df['close'], 20)
        df['sma50'] = sma(df['close'], 50)
        df['rsi'] = rsi(df['close'], 14)
        macd_line, signal_line, hist = macd(df['close'])
        df['macd_hist'] = hist
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        trend = 1 if latest['sma20'] > latest['sma50'] else -1
        rsi_sig = 1 if latest['rsi'] < 30 else (-1 if latest['rsi'] > 70 else 0)
        macd_sig = 1 if (prev['macd_hist'] < 0 and latest['macd_hist'] > 0) else (-1 if (prev['macd_hist'] > 0 and latest['macd_hist'] < 0) else 0)
        vol = df['close'].pct_change().rolling(14).std().iloc[-1]
        vol_sig = 0 if vol > 0.01 else 1
        return {'trend': trend, 'rsi': rsi_sig, 'macd': macd_sig, 'vol': vol_sig}

    def decide_and_execute(self, dfs_multi_tf, account_balance):
        low_tf = list(dfs_multi_tf.keys())[-1]
        df_low = dfs_multi_tf[low_tf]
        signals = self.compute_signals(df_low)
        # multi-timeframe confirmation
        for tf in dfs_multi_tf:
            if tf == low_tf:
                continue
            tdf = dfs_multi_tf[tf]
            t_trend = 1 if sma(tdf['close'], 20).iloc[-1] > sma(tdf['close'], 50).iloc[-1] else -1
            if t_trend != signals['trend']:
                return None
        # smart money filters
        obs = detect_order_blocks_from_ohlc(df_low)
        latest_price = df_low['close'].iloc[-1]
        for ob in obs[-3:]:
            if ob['side'] == 'bear' and signals['trend'] == 1 and ob['low'] < latest_price < ob['high']:
                return None
            if ob['side'] == 'bull' and signals['trend'] == -1 and ob['low'] < latest_price < ob['high']:
                return None
        signal_vec = np.array([signals['trend'], signals['rsi'], signals['macd'], signals['vol']])
        score = self.meta.predict_weighted_signal(signal_vec)
        if abs(score) < 0.5:
            return None
        side = 'BUY' if score > 0 else 'SELL'
        if side == 'BUY':
            stop = float(df_low['low'].iloc[-10:].min())
            stop_pips = (df_low['close'].iloc[-1] - stop) / 0.0001
        else:
            stop = float(df_low['high'].iloc[-10:].max())
            stop_pips = (stop - df_low['close'].iloc[-1]) / 0.0001
        lot = position_size(account_balance, stop_pips)
        # For Deriv: map lot -> amount stake (simplified)
        amount = max(1.0, round(lot * 10, 2))
        if not self.psych.allow_trade():
            return None
        if isinstance(self.broker, DerivAdapter):
            contract_type = 'CALL' if side == 'BUY' else 'PUT'
            res = self.broker.create_order(symbol='frxEURUSD', amount=amount, contract_type=contract_type, duration=1)
        else:
            units = int(lot * 100000) * (1 if side == 'BUY' else -1)
            res = self.broker.create_order('EUR_USD', units, stop=stop, tp=None)
        self.order_history.append({'time': now_utc(), 'side': side, 'units': amount if isinstance(self.broker, DerivAdapter) else units, 'stop': stop, 'res': res})
        return res

# ---------------- Flask UI with Start/Stop ----------------
app = Flask('Alhamdulila_UI')
engine_global = None
bot_state = {
    'exec_allowed': False,  # controls trade execution only
    'running': False,       # whether background loop thread is active
    'mode': 'idle',         # backtest/paper/live/deriv_demo
    'last_error': None
}

TEMPLATE = """
<!doctype html>
<title>Alhamdulila — Forex AI Bot</title>
<h2>Alhamdulila — Forex AI Bot</h2>
<p>Mode: {{mode}} | Exec Allowed: <b style='color:{{\"green\" if exec_allowed else \"red\"}}'>{{exec_allowed}}</b></p>
<form method="post" action="/control">
  <button name="cmd" value="start" style="background:green;color:white;padding:10px 20px;border:none">Start Bot</button>
  <button name="cmd" value="stop" style="background:red;color:white;padding:10px 20px;border:none">Stop Bot</button>
</form>
<h3>Account</h3>
<p>Balance: {{balance}}</p>
<h3>Recent Orders</h3>
<ul>
{% for o in orders %}
  <li>{{o.time}} — {{o.side}} — {{o.units}} — stop={{o.stop}}</li>
{% endfor %}
</ul>
{% if last_error %}
<hr/><h4 style="color:darkred">Last Error</h4><pre>{{last_error}}</pre>
{% endif %}
"""

def safe_route(f):
    @wraps(f)
    def wrapped(*a, **k):
        try:
            return f(*a, **k)
        except Exception as e:
            bot_state['last_error'] = traceback.format_exc()
            return ("ERROR: " + str(e), 500)
    return wrapped

@app.route('/')
@safe_route
def index():
    orders = engine_global.order_history[-20:] if engine_global else []
    balance = getattr(engine_global.broker, 'balance', 0.0) if engine_global else 0.0
    return render_template_string(TEMPLATE, mode=bot_state['mode'], exec_allowed=bot_state['exec_allowed'], orders=orders, balance=balance, last_error=bot_state['last_error'])

@app.route('/control', methods=['POST'])
@safe_route
def control():
    cmd = request.form.get('cmd')
    if cmd == 'start':
        bot_state['exec_allowed'] = True
    elif cmd == 'stop':
        bot_state['exec_allowed'] = False
    return redirect(url_for('index'))

# Background trading thread (executes decision only when exec_allowed is True)
def trading_loop(engine: StrategyEngine, broker, loop_interval=LOOP_INTERVAL_SEC):
    bot_state['running'] = True
    try:
        # simple bar buffers for demo (real system should use tick streaming->resample to bars)
        buffer_m5 = pd.DataFrame(columns=['open','high','low','close'])
        buffer_h1 = pd.DataFrame(columns=['open','high','low','close'])
        # For demo/backtest, you would fill buffers from tick replay or broker ticks
        while bot_state['running']:
            try:
                account = broker.get_account()
                balance = float(account.get('balance', 10000.0))
                # Here we simulate fetching OHLC bars by using random walk when no real data
                # In production: replace with actual bar building from ticks
                # For demo we create small randomized bars:
                t = pd.Timestamp.utcnow().floor('5T')
                price = 1.1000 + (np.random.rand()-0.5)*0.002
                bar = {'open': price, 'high': price + 0.0005, 'low': price - 0.0005, 'close': price}
                # append to buffers with timestamp index
                buffer_m5.loc[t] = bar
                if len(buffer_m5) > 200:
                    buffer_m5 = buffer_m5.iloc[-200:]
                # build H1 by resampling (here simulated)
                if len(buffer_m5) >= 12:
                    # create H1 by aggregating latest 12x5T bars
                    h1_idx = buffer_m5.index[-12:]
                    seg = buffer_m5.loc[h1_idx]
                    h1 = {'open': seg['open'].iloc[0], 'high': seg['high'].max(), 'low': seg['low'].min(), 'close': seg['close'].iloc[-1]}
                    buffer_h1.loc[pd.Timestamp.utcnow().floor('60T')] = h1
                    if len(buffer_h1) > 200:
                        buffer_h1 = buffer_h1.iloc[-200:]
                dfs = {'H1': buffer_h1.copy(), 'M5': buffer_m5.copy()}
                # Decide & execute only when exec_allowed True
                if bot_state['exec_allowed'] and len(buffer_m5) > 60:
                    res = engine.decide_and_execute(dfs, balance)
                    if res:
                        print('Order result:', res)
                time.sleep(loop_interval)
            except Exception as e:
                print('Loop error', e)
                bot_state['last_error'] = traceback.format_exc()
                time.sleep(loop_interval)
    finally:
        bot_state['running'] = False

# ---------------- Run orchestration ----------------
def start_engine_and_ui(broker_name='backtest', mode='paper'):
    global engine_global
    if broker_name == 'deriv':
        app_id = os.getenv('DERIV_APP_ID', '1089')
        token = os.getenv('DERIV_TOKEN', '')
        broker = DerivAdapter(app_id, token)
        broker.connect()
    else:
        broker = BrokerAdapter()
        broker.connect()
    engine = StrategyEngine(broker)
    engine_global = engine
    bot_state['mode'] = mode
    # start UI thread
    ui_thread = threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False))
    ui_thread.daemon = True
    ui_thread.start()
    # start trading loop thread
    trade_thread = threading.Thread(target=trading_loop, args=(engine, broker))
    trade_thread.daemon = True
    trade_thread.start()
    return engine, broker

def stop_all():
    bot_state['running'] = False
    bot_state['exec_allowed'] = False

# ---------------- CLI ----------------
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['backtest','paper','live','deriv_demo'], default='paper')
    parser.add_argument('--broker', choices=['deriv','backtest'], default='deriv')
    parser.add_argument('--data-file', default='data/EUR_USD_ticks.parquet')
    args = parser.parse_args()

    if args.mode == 'backtest':
        print('Backtest mode (not fully implemented in sealed file). Use earlier prototype for heavy backtests.')
        # simple demo: load data if present (user can expand)
        if os.path.exists(args.data_file):
            print('Would run backtest on', args.data_file)
        else:
            print('No data file found at', args.data_file)
    else:
        print('Starting UI and engine. Open http://127.0.0.1:5000 in your phone browser.')
        engine, broker = start_engine_and_ui(broker_name=args.broker, mode=args.mode)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print('Shutting down...')
            stop_all()

